import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <>
    <footer className="footer">
      <span className="footer-text">Đây là footer</span>
    </footer>
    </>
  );
};

export default Footer;
