import React from 'react';
import { Outlet, Route, Routes } from 'react-router-dom';
import Footer from './Component/Footer/Footer';
import Header from './Component/Header/Header';
import LoginPage from './Component/LoginPage/LoginPage';
import RegisterPage from './Component/RegisterPage/RegisterPage';
import BookTableBody from './Component/Body/BookTableBody';

const App = () => {
  return (
    <>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/" element={<MainPage />} />
      </Routes>
    </>
  );
};
  

const MainPage = () => {
  return (
    <>
      <Header />
      <BookTableBody />
      <Footer />
    </>
  );
};

export default App;
