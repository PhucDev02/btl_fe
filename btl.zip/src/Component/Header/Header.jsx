import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

const Header = () => {
    return (
        <header className="header">
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-3">
                        <img
                            src="https://thumbs.dreamstime.com/b/beautiful-meticulously-designed-library-icon-perfect-use-designing-developing-websites-printed-materials-presentations-112019830.jpg"
                            alt="Logo"
                            className="logo"
                            style={{ width: '50px', height: '50px' }}
                        />
                    </div>
                    <div className="col-6 text-center">
                        <h1 className="header-title">BTL Web</h1>
                    </div>
                    <div className="col-3 text-right">
                        <Link to="/login" className="btn btn-success">Login</Link>
                        <Link to="/register" className="btn btn-primary"> Register </Link>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
