import React from "react";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
const BookTableBody = () => {
    const [book, setBook] = useState([]);
    const [remain, setRemain] = useState([]);
    useEffect(() => {
        console.log("Book");
        fetch("http://localhost:8080/books")
            .then((response) => response.json())
            .then((data) => {
                console.log(data);
                setBook(data);
            })
            .catch((err) => console.log(err));
    }, []);

    useEffect(() => {
        setRemain(book);
    }, [book]);


    return (
        <div>
            <div className="container">
                <br></br>
                <table className="table table-striped table-bordered">
                    <thead className="table-dark">
                        <tr>
                            <th className="text-center">Title</th>
                            <th className="text-center">Author</th>
                            <th className="text-center">Release</th>
                            <th className="text-center">Page Num</th>
                            <th className="text-center">Sold Quantity</th>
                            <th className="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {remain.map((Book) => (
                            <tr key={Book.id}>
                                <td >{Book.title}</td>
                                <td >{Book.author}</td>
                                <td className="text-center">{Book.releaseDate}</td>
                                <td className="text-center">{Book.pageNum}</td>
                                <td className="text-center">{Book.pageNum}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                <div className="d-flex justify-content-center">
                    <button className="btn btn-primary">Add New</button>
                </div>

            </div>
        </div>
    );
};
export default BookTableBody;